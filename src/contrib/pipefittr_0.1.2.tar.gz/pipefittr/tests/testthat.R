##
## [testthat.r]
##
## author     : Ed Goodwin
## project    : pipefittr
## createdate : 05.07.2016
##
## description:
##    test scaffolding for pipefittr
##    run tests with devtools::test() in R console
##
## version: 0.01
## changelog:
##

library(testthat)
library(pipefittr)

test_check("pipefittr")
